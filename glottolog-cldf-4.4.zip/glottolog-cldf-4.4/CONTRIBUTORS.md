# Contributors

name | affiliation | orcid | github | role
---  | ----------- | ----- | ------ | ----
Harald Hammarström | University Uppsala |  | @d97hah | maintainer
Robert Forkel | Max Planck Institute for Evolutionary Anthropology | 0000-0003-1081-086X | @xrotwang | maintainer
Martin Haspelmath | Max Planck Institute for Evolutionary Anthropology | 0000-0003-2100-8493 | @haspelmath | maintainer
Sebastian Bank |  | 0000-0002-2676-6296 | @xflr6 | maintainer